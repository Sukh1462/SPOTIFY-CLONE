export const environment = {
  production: true,
  clientID: "f3a26071061f404491508fb843b60eed",
  clientSecret:"71436c91e55a4095b89ce75b86a47931"
};
