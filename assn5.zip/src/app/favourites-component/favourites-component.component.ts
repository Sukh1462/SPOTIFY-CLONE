import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-favourites-component',
  templateUrl: './favourites-component.component.html',
  styleUrls: ['./favourites-component.component.css']
})
export class FavouritesComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
